# Copia de skills globales de OpenCode

Copiada el 2026-10-29 desde `C:\Users\Diego\.config\opencode\skills`.
Cada subcarpeta es una skill: la que contiene `SKILL.md` es la unidad que OpenCode detecta por el nombre de la carpeta.

Origen: copia literal, verificada fichero a fichero con SHA256 contra el directorio de origen (45 ficheros, 382.627 bytes, 0 diferencias).

| Skill | Ficheros | Bytes | Procedencia |
|---|---|---|---|
| `antislop` | 2 | 61.026 | `npx antislop-ai` |
| `antislop-code` | 1 | 8.944 | `npx antislop-ai` |
| `antislop-copywriting` | 1 | 25.419 | `npx antislop-ai` |
| `antislop-human` | 6 | 42.021 | `npx antislop-ai` |
| `antislop-ui` | 4 | 40.107 | `npx antislop-ai` |
| `clean-code` | 7 | 46.182 | ZIP `clean-code.skill` (web del autor, YAML re-serializado) |
| `code-review-mastery` | 6 | 36.775 | commit `1c8c79ae7d24df8779cb7847e676a3ab73bd400b` |
| `clean-architecture` | 8 | 54.702 | commit `1c8c79ae7d24df8779cb7847e676a3ab73bd400b` |
| `refactoring-patterns` | 5 | 33.448 | commit `1c8c79ae7d24df8779cb7847e676a3ab73bd400b` |
| `test-strategy` | 5 | 34.003 | commit `1c8c79ae7d24df8779cb7847e676a3ab73bd400b` |

## Estado del contenido

- Las cinco `clean-*` son MIT, del repo `maddhruv/absolute` (antes `AbsolutelySkilled/AbsolutelySkilled`). Ya no existen en su `main`: se retiraron en el commit `1ad2c4b` del 2026-06-05. Los detalles por fichero están en el `PROVENANCE.md` de cada una, salvo en `clean-code`, que vino del ZIP y no tiene.
- Única edición local en las `clean-*`: fuera la línea de cada `SKILL.md` que ordenaba al agente empezar su primera respuesta con un emoji.
- **Sin tocar:** la sección *Companion check* al final de los cinco `SKILL.md`, que manda escanear carpetas de skills y ofrecer `npx skills add AbsolutelySkilled/AbsolutelySkilled --skill <nombre>`. El repo está renombrado y el dominio `absolutelyskilled.pro` tiene el certificado caducado desde el 2026-09-22, así que ese comando ya no funciona.
- Las `antislop-*` se gestionan con `npx antislop-ai --update`; esta copia es solo respaldo, no la uses para reinstalarlas.
